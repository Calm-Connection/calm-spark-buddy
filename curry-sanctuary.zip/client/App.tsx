import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";

// Landing & Auth
import Index from "./pages/Index";
import Login from "./pages/Login";
import RoleSelection from "./pages/RoleSelection";
import Placeholder from "./pages/Placeholder";

// Carer Flow
import CarerCreateAccount from "./pages/CarerCreateAccount";
import CarerPrivacy from "./pages/CarerPrivacy";
import CarerInviteCode from "./pages/CarerInviteCode";
import CarerPickAvatar from "./pages/CarerPickAvatar";
import CarerHome from "./pages/CarerHome";
import CarerWeeklyInsights from "./pages/CarerWeeklyInsights";
import CarerLearn from "./pages/CarerLearn";
import CarerJointTools from "./pages/CarerJointTools";

// Child Flow
import ChildEnterInviteCode from "./pages/ChildEnterInviteCode";
import ChildCreateAvatar from "./pages/ChildCreateAvatar";
import ChildPickTheme from "./pages/ChildPickTheme";
import ChildSafetyNote from "./pages/ChildSafetyNote";
import ChildQuickTour from "./pages/ChildQuickTour";
import ChildHome from "./pages/ChildHome";

// Shared Features
import JournalEntry from "./pages/JournalEntry";
import Tools from "./pages/Tools";
import Learn from "./pages/Learn";
import AllEntries from "./pages/AllEntries";
import Helpline from "./pages/Helpline";

import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          {/* Landing & Auth */}
          <Route path="/" element={<Index />} />
          <Route path="/login" element={<Login />} />
          <Route path="/role-selection" element={<RoleSelection />} />
          <Route path="/placeholder" element={<Placeholder />} />

          {/* Carer Sign-up Flow */}
          <Route path="/carer-create-account" element={<CarerCreateAccount />} />
          <Route path="/carer-privacy" element={<CarerPrivacy />} />
          <Route path="/carer-invite-code" element={<CarerInviteCode />} />
          <Route path="/carer-pick-avatar" element={<CarerPickAvatar />} />

          {/* Carer Home & Dashboard */}
          <Route path="/carer-home" element={<CarerHome />} />
          <Route path="/carer-weekly-insights" element={<CarerWeeklyInsights />} />
          <Route path="/carer-learn" element={<CarerLearn />} />
          <Route path="/carer-joint-tools" element={<CarerJointTools />} />

          {/* Child Sign-up Flow */}
          <Route path="/child-enter-invite-code" element={<ChildEnterInviteCode />} />
          <Route path="/child-create-avatar" element={<ChildCreateAvatar />} />
          <Route path="/child-pick-theme" element={<ChildPickTheme />} />
          <Route path="/child-safety-note" element={<ChildSafetyNote />} />
          <Route path="/child-quick-tour" element={<ChildQuickTour />} />

          {/* Child Home */}
          <Route path="/child-home" element={<ChildHome />} />

          {/* Shared Features */}
          <Route path="/journal-entry" element={<JournalEntry />} />
          <Route path="/tools" element={<Tools />} />
          <Route path="/learn" element={<Learn />} />
          <Route path="/all-entries" element={<AllEntries />} />
          <Route path="/helpline" element={<Helpline />} />

          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

createRoot(document.getElementById("root")!).render(<App />);
