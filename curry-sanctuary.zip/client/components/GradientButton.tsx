import { cn } from "@/lib/utils";
import { ButtonHTMLAttributes, forwardRef } from "react";

export interface GradientButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary";
}

export const GradientButton = forwardRef<HTMLButtonElement, GradientButtonProps>(
  ({ className, variant = "primary", children, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(
          "relative rounded-full font-balsamiq text-calm-text font-normal transition-transform hover:scale-105 active:scale-95 shadow-md",
          variant === "primary" && "px-7 py-4 text-[32px] leading-8",
          variant === "secondary" && "px-6 py-3 text-xl leading-6",
          className
        )}
        style={{
          background: "linear-gradient(93deg, #D2ABFF 1.75%, #FFDAA7 49.56%, #FCF0CC 97.38%)",
        }}
        {...props}
      >
        {children}
      </button>
    );
  }
);

GradientButton.displayName = "GradientButton";
