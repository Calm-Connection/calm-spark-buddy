import { Link } from "react-router-dom";
import { TopRightShape, BottomLeftShape } from "@/components/DecorativeShapes";
import { GradientButton } from "@/components/GradientButton";
import { useState } from "react";

export default function ChildEnterInviteCode() {
  const [code, setCode] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-calm-bg relative overflow-hidden">
      <TopRightShape />
      <BottomLeftShape />
      
      <Link
        to="/role-selection"
        className="absolute top-8 left-4 z-20 p-2 hover:bg-black/5 rounded-full transition-colors"
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M14 18L8 12L14 6L15.4 7.4L10.8 12L15.4 16.6L14 18Z" fill="#1D1B20" />
        </svg>
      </Link>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 py-12">
        <div className="flex flex-col items-center max-w-[375px] w-full">
          <div className="w-[113px] h-[113px] mb-6 flex items-center justify-center">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/52e024e4615122cbeb548c13ef1bbaa053452ca4?width=226"
              alt="Logo"
              className="w-full h-full object-contain"
            />
          </div>

          {!submitted ? (
            <>
              <h1 className="text-[36px] font-bold font-balsamiq text-black text-center mb-6">
                ENTER MY PARENT CODE
              </h1>

              <form onSubmit={handleSubmit} className="w-full flex flex-col items-center gap-6 mb-8">
                <input
                  type="text"
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  placeholder="Enter code here"
                  className="w-full max-w-[259px] h-16 px-4 rounded-[10px] border-2 border-black bg-white font-balsamiq text-center text-lg placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-calm-purple"
                />

                <GradientButton variant="secondary" type="submit">
                  SUBMIT
                </GradientButton>
              </form>
            </>
          ) : (
            <>
              <h1 className="text-[36px] font-bold font-balsamiq text-black text-center mb-8">
                THANK YOU!
              </h1>
              <p className="text-xl font-balsamiq text-black text-center mb-8">
                Code verified successfully. Let's continue setting up your account.
              </p>
              <Link to="/child-create-avatar">
                <GradientButton variant="secondary">
                  CONTINUE
                </GradientButton>
              </Link>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
