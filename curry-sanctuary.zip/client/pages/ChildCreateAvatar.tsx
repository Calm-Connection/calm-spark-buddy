import { Link } from "react-router-dom";
import { TopRightShape, BottomLeftShape } from "@/components/DecorativeShapes";
import { GradientButton } from "@/components/GradientButton";
import { useState } from "react";

export default function ChildCreateAvatar() {
  const [avatar, setAvatar] = useState({
    skinTone: "",
    eyeHair: "",
    hairStyle: "",
    favoriteColor: "",
    accessories: "",
    comfortItem: "",
  });

  return (
    <div className="min-h-screen bg-calm-bg relative overflow-hidden">
      <TopRightShape />
      <BottomLeftShape />
      
      <Link
        to="/child-enter-invite-code"
        className="absolute top-8 left-4 z-20 p-2 hover:bg-black/5 rounded-full transition-colors"
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M14 18L8 12L14 6L15.4 7.4L10.8 12L15.4 16.6L14 18Z" fill="#1D1B20" />
        </svg>
      </Link>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 py-8">
        <div className="flex flex-col items-center max-w-[375px] w-full">
          <div className="w-[128px] h-[128px] mb-6 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
            <svg
              width="128"
              height="128"
              viewBox="0 0 128 128"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <rect width="128" height="128" rx="64" fill="#EADDFF" />
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M83.2008 51.2C83.2008 61.8039 74.6047 70.4 64.0008 70.4C53.3969 70.4 44.8008 61.8039 44.8008 51.2C44.8008 40.5961 53.3969 32 64.0008 32C74.6047 32 83.2008 40.5961 83.2008 51.2ZM76.8008 51.2C76.8008 58.2692 71.07 64 64.0008 64C56.9315 64 51.2008 58.2692 51.2008 51.2C51.2008 44.1308 56.9315 38.4 64.0008 38.4C71.07 38.4 76.8008 44.1308 76.8008 51.2Z"
                fill="#4F378A"
              />
              <path
                d="M64.0008 80C43.2828 80 25.6305 92.2509 18.9062 109.415C20.5443 111.041 22.2699 112.58 24.0753 114.023C29.0825 98.2646 44.7903 86.4 64.0008 86.4C83.2113 86.4 98.9191 98.2646 103.926 114.023C105.732 112.58 107.457 111.041 109.095 109.415C102.371 92.2509 84.7188 80 64.0008 80Z"
                fill="#4F378A"
              />
            </svg>
          </div>

          <h1 className="text-[29px] font-bold font-balsamiq text-black text-center mb-8">
            CREATE YOUR AVATAR
          </h1>

          {/* Customization Options */}
          <div className="space-y-4 w-full mb-8">
            {[
              { label: "SKIN TONE", key: "skinTone" },
              { label: "EYE & HAIR COLOUR", key: "eyeHair" },
              { label: "HAIR STYLE", key: "hairStyle" },
              { label: "FAVOURITE COLOUR", key: "favoriteColor" },
              { label: "ACCESSORIES", key: "accessories" },
              { label: "COMFORT ITEM", key: "comfortItem" },
            ].map((option) => (
              <div
                key={option.key}
                className="bg-calm-cream rounded-[11px] h-14 flex items-center justify-center"
              >
                <p className="text-xl font-balsamiq text-black text-center">
                  {option.label}
                </p>
              </div>
            ))}
          </div>

          {/* Submit Button */}
          <GradientButton variant="secondary" className="text-2xl py-3 px-6">
            SUBMIT
          </GradientButton>
        </div>
      </div>
    </div>
  );
}
