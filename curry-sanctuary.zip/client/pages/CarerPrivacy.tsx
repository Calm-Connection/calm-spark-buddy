import { Link } from "react-router-dom";
import { TopRightShape, BottomLeftShape } from "@/components/DecorativeShapes";
import { useState } from "react";

export default function CarerPrivacy() {
  const [agreed, setAgreed] = useState(false);

  return (
    <div className="min-h-screen bg-calm-bg relative overflow-hidden">
      <TopRightShape />
      <BottomLeftShape />
      
      <Link
        to="/carer-create-account"
        className="absolute top-8 left-4 z-20 p-2 hover:bg-black/5 rounded-full transition-colors"
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M14 18L8 12L14 6L15.4 7.4L10.8 12L15.4 16.6L14 18Z" fill="#1D1B20" />
        </svg>
      </Link>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 py-12">
        <div className="flex flex-col items-center max-w-[375px] w-full">
          <div className="w-[318px] h-[318px] mb-6 flex items-center justify-center">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/f722ac5c1a6e81a8352dc90eaf18b6c29d5963c0?width=636"
              alt="Calm Connection Logo"
              className="w-full h-full object-contain"
            />
          </div>

          {/* Privacy Card */}
          <div className="bg-white rounded-[53px] p-8 w-full max-w-[330px]">
            {/* Heart Icon */}
            <div className="flex justify-center mb-6">
              <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M29.5233 6.53073C28.7998 5.80682 27.9406 5.23257 26.9951 4.84077C26.0495 4.44897 25.036 4.24731 24.0125 4.24731C22.989 4.24731 21.9755 4.44897 21.0299 4.84077C20.0843 5.23257 19.2252 5.80682 18.5017 6.53073L17 8.0324L15.4983 6.53073C14.0368 5.06917 12.0545 4.24807 9.9875 4.24807C7.92053 4.24807 5.93823 5.06917 4.47666 6.53073C3.0151 7.9923 2.194 9.9746 2.194 12.0416C2.194 14.1085 3.0151 16.0908 4.47666 17.5524L17 30.0757L29.5233 17.5524C30.2472 16.8288 30.8215 15.9697 31.2133 15.0242C31.6051 14.0786 31.8067 13.0651 31.8067 12.0416C31.8067 11.018 31.6051 10.0045 31.2133 9.05898C30.8215 8.11341 30.2472 7.2543 29.5233 6.53073Z"
                  stroke="#1E1E1E"
                  strokeWidth="4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>

            {/* Content */}
            <div className="text-black font-balsamiq text-center mb-8">
              <p className="font-bold text-[24px] mb-4">Your privacy matters to us.</p>
              <p className="text-[20px] mb-4">
                We only use your data in line with your chosen settings and our Privacy Policy.
              </p>
              <p className="text-[20px] mb-6">
                Please avoid sharing sensitive personal details.
              </p>
              <a href="#" className="text-[20px] underline hover:no-underline">
                Privacy & Safeguarding Policy
              </a>
            </div>

            {/* Checkbox */}
            <div className="flex items-center gap-4 mb-6">
              <input
                type="checkbox"
                id="agree"
                checked={agreed}
                onChange={(e) => setAgreed(e.target.checked)}
                className="w-6 h-6 rounded border-2 border-black cursor-pointer"
              />
              <label htmlFor="agree" className="font-bold font-balsamiq text-[20px] text-black cursor-pointer">
                I've read and understood
              </label>
            </div>
          </div>

          {/* Continue Button */}
          <Link
            to={agreed ? "/carer-invite-code" : "#"}
            onClick={(e) => !agreed && e.preventDefault()}
            className={`mt-8 px-8 py-4 rounded-full font-balsamiq text-[32px] font-normal transition-all ${
              agreed
                ? "bg-gradient-to-r from-calm-purple via-calm-peach to-calm-cream cursor-pointer hover:shadow-lg"
                : "bg-gray-300 cursor-not-allowed opacity-50"
            }`}
          >
            CONTINUE
          </Link>
        </div>
      </div>
    </div>
  );
}
