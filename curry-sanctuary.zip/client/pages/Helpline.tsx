import { Link } from "react-router-dom";
import { TopRightShape, BottomLeftShape } from "@/components/DecorativeShapes";

export default function Helpline() {
  return (
    <div className="min-h-screen bg-calm-bg relative overflow-hidden pb-20">
      <TopRightShape />
      <BottomLeftShape />
      
      <Link
        to="/child-home"
        className="absolute top-8 left-4 z-20 p-2 hover:bg-black/5 rounded-full transition-colors"
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M14 18L8 12L14 6L15.4 7.4L10.8 12L15.4 16.6L14 18Z" fill="#1D1B20" />
        </svg>
      </Link>

      <div className="relative z-10 px-6 py-8">
        <div className="bg-white rounded-[24px] p-8 max-w-[330px] mx-auto">
          <h1 className="text-[24px] font-bold font-balsamiq text-black text-center mb-4">
            You're not alone, and help is always here 🌷
          </h1>

          <p className="text-base font-balsamiq text-black text-center mb-6">
            Sometimes things can feel really heavy or confusing and that's okay. If you'd like to talk to someone, these people are trained to listen and help you feel safe.
          </p>

          {/* Helplines */}
          <div className="space-y-6 mb-8">
            {/* Childline */}
            <div className="border-b-2 border-gray-200 pb-4">
              <h2 className="font-bold font-balsamiq text-lg text-black mb-2">
                Childline – Chat online or call 0800 1111
              </h2>
              <p className="text-sm font-balsamiq text-black mb-3">
                Free, confidential support for young people anytime.
              </p>
              <div className="flex gap-2">
                <button className="flex-1 bg-calm-purple text-black font-balsamiq font-semibold py-2 rounded-full hover:shadow-lg transition-shadow text-sm">
                  Chat now
                </button>
                <button className="flex-1 bg-calm-purple text-black font-balsamiq font-semibold py-2 rounded-full hover:shadow-lg transition-shadow text-sm">
                  Call
                </button>
              </div>
            </div>

            {/* YoungMinds */}
            <div className="border-b-2 border-gray-200 pb-4">
              <h2 className="font-bold font-balsamiq text-lg text-black mb-2">
                YoungMinds Textline – Text YM to 85258
              </h2>
              <p className="text-sm font-balsamiq text-black mb-3">
                You can text for support 24/7 about anything that's worrying you.
              </p>
              <button className="w-full bg-calm-purple text-black font-balsamiq font-semibold py-2 rounded-full hover:shadow-lg transition-shadow text-sm">
                Text now
              </button>
            </div>

            {/* Samaritans */}
            <div>
              <h2 className="font-bold font-balsamiq text-lg text-black mb-2">
                Samaritans – Call 116 123
              </h2>
              <p className="text-sm font-balsamiq text-black mb-3">
                If you ever need someone to listen, day or night.
              </p>
              <button className="w-full bg-calm-purple text-black font-balsamiq font-semibold py-2 rounded-full hover:shadow-lg transition-shadow text-sm">
                Call
              </button>
            </div>
          </div>

          {/* Footer Message */}
          <p className="text-xs font-balsamiq text-black text-center">
            You're doing the right thing by reaching out. Talking about how you feel is a brave and powerful step. 💛
          </p>
        </div>
      </div>
    </div>
  );
}
