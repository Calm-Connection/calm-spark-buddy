import { Link } from "react-router-dom";
import { TopRightShape, BottomLeftShape } from "@/components/DecorativeShapes";
import { GradientButton } from "@/components/GradientButton";
import { useState } from "react";

export default function CarerCreateAccount() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Navigate to privacy page
  };

  return (
    <div className="min-h-screen bg-calm-bg relative overflow-hidden">
      <TopRightShape />
      <BottomLeftShape />
      
      <Link
        to="/role-selection"
        className="absolute top-8 left-4 z-20 p-2 hover:bg-black/5 rounded-full transition-colors"
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M14 18L8 12L14 6L15.4 7.4L10.8 12L15.4 16.6L14 18Z" fill="#1D1B20" />
        </svg>
      </Link>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 py-12">
        <div className="flex flex-col items-center max-w-[375px] w-full">
          <div className="w-[318px] h-[318px] mb-6 flex items-center justify-center">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/f722ac5c1a6e81a8352dc90eaf18b6c29d5963c0?width=636"
              alt="Calm Connection Logo"
              className="w-full h-full object-contain"
            />
          </div>

          <h1 className="text-[24px] font-bold font-balsamiq text-black text-center mb-8">
            CREATE YOUR ACCOUNT
          </h1>

          <form onSubmit={handleSubmit} className="w-full flex flex-col items-center gap-6">
            {/* Email Input */}
            <div className="relative w-full max-w-[300px]">
              <div className="absolute left-4 top-1/2 -translate-y-1/2">
                <svg
                  width="46"
                  height="46"
                  viewBox="0 0 46 46"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M11.2125 32.775C12.8417 31.5292 14.6625 30.5469 16.675 29.8282C18.6875 29.1094 20.7959 28.75 23 28.75C25.2042 28.75 27.3125 29.1094 29.325 29.8282C31.3375 30.5469 33.1584 31.5292 34.7875 32.775C35.9056 31.4653 36.7761 29.9799 37.399 28.3188C38.0219 26.6577 38.3334 24.8848 38.3334 23C38.3334 18.7514 36.84 15.1337 33.8532 12.1469C30.8664 9.16011 27.2487 7.66671 23 7.66671C18.7514 7.66671 15.1337 9.16011 12.1469 12.1469C9.16011 15.1337 7.66671 18.7514 7.66671 23C7.66671 24.8848 7.97817 26.6577 8.60108 28.3188C9.224 29.9799 10.0945 31.4653 11.2125 32.775ZM23 24.9167C21.1153 24.9167 19.5261 24.2698 18.2323 22.9761C16.9386 21.6823 16.2917 20.0931 16.2917 18.2084C16.2917 16.3237 16.9386 14.7344 18.2323 13.4407C19.5261 12.1469 21.1153 11.5 23 11.5C24.8848 11.5 26.474 12.1469 27.7677 13.4407C29.0615 14.7344 29.7084 16.3237 29.7084 18.2084C29.7084 20.0931 29.0615 21.6823 27.7677 22.9761C26.474 24.2698 24.8848 24.9167 23 24.9167ZM23 42.1667C20.3487 42.1667 17.857 41.6636 15.525 40.6573C13.1931 39.6511 11.1646 38.2855 9.43962 36.5605C7.71462 34.8355 6.349 32.807 5.34275 30.475C4.3365 28.1431 3.83337 25.6514 3.83337 23C3.83337 20.3487 4.3365 17.857 5.34275 15.525C6.349 13.1931 7.71462 11.1646 9.43962 9.43962C11.1646 7.71462 13.1931 6.349 15.525 5.34275C17.857 4.3365 20.3487 3.83337 23 3.83337C25.6514 3.83337 28.1431 4.3365 30.475 5.34275C32.807 6.349 34.8355 7.71462 36.5605 9.43962C38.2855 11.1646 39.6511 13.1931 40.6573 15.525C41.6636 17.857 42.1667 20.3487 42.1667 23C42.1667 25.6514 41.6636 28.1431 40.6573 30.475C39.6511 32.807 38.2855 34.8355 36.5605 36.5605C34.8355 38.2855 32.807 39.6511 30.475 40.6573C28.1431 41.6636 25.6514 42.1667 23 42.1667Z"
                    fill="#FCF0CC"
                  />
                </svg>
              </div>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="EMAIL"
                className="w-full h-8 pl-16 pr-4 rounded-[19px] border border-black bg-white font-balsamiq text-base placeholder:text-black focus:outline-none focus:ring-2 focus:ring-calm-purple"
              />
            </div>

            {/* Password Input */}
            <div className="relative w-full max-w-[300px]">
              <div className="absolute left-4 top-1/2 -translate-y-1/2">
                <svg
                  width="45"
                  height="45"
                  viewBox="0 0 45 45"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M13.125 20.625V13.125C13.125 10.6386 14.1127 8.25403 15.8709 6.49587C17.629 4.73772 20.0136 3.75 22.5 3.75C24.9864 3.75 27.371 4.73772 29.1291 6.49587C30.8873 8.25403 31.875 10.6386 31.875 13.125V20.625M9.375 20.625H35.625C37.6961 20.625 39.375 22.3039 39.375 24.375V37.5C39.375 39.5711 37.6961 41.25 35.625 41.25H9.375C7.30393 41.25 5.625 39.5711 5.625 37.5V24.375C5.625 22.3039 7.30393 20.625 9.375 20.625Z"
                    stroke="#FCF0CC"
                    strokeWidth="4"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="PASSWORD"
                className="w-full h-8 pl-16 pr-4 rounded-[19px] border border-black bg-white font-balsamiq text-base placeholder:text-black focus:outline-none focus:ring-2 focus:ring-calm-purple"
              />
            </div>

            {/* Submit Button */}
            <Link to="/carer-privacy">
              <GradientButton variant="secondary" type="submit" className="mt-4">
                SUBMIT
              </GradientButton>
            </Link>
          </form>
        </div>
      </div>
    </div>
  );
}
