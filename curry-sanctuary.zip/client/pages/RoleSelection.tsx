import { Link } from "react-router-dom";
import { TopRightShape, BottomLeftShape } from "@/components/DecorativeShapes";

export default function RoleSelection() {
  return (
    <div className="min-h-screen bg-calm-bg relative overflow-hidden">
      <TopRightShape />
      <BottomLeftShape />
      
      {/* Back button */}
      <Link
        to="/login"
        className="absolute top-8 left-3 z-20 p-2 hover:bg-black/5 rounded-full transition-colors"
      >
        <svg
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M14 18L8 12L14 6L15.4 7.4L10.8 12L15.4 16.6L14 18Z"
            fill="#1D1B20"
          />
        </svg>
      </Link>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 py-12">
        <div className="flex flex-col items-center max-w-[375px] w-full">
          {/* Logo */}
          <div className="w-[318px] h-[318px] mb-4 flex items-center justify-center">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/f722ac5c1a6e81a8352dc90eaf18b6c29d5963c0?width=636"
              alt="Calm Connection Logo"
              className="w-full h-full object-contain"
            />
          </div>

          {/* Title */}
          <h1 className="text-[32px] font-bold font-balsamiq text-black text-center leading-6 mb-6">
            WHO'S LOGGING IN?
          </h1>

          {/* Role Cards */}
          <div className="flex gap-6 mb-6">
            {/* Carer Card */}
            <Link
              to="/carer-create-account"
              className="w-[143px] h-[164px] rounded-[30px] bg-white flex flex-col items-center justify-between p-4 hover:shadow-lg transition-shadow"
            >
              <div className="flex-1 flex items-center justify-center">
                <img
                  src="https://api.builder.io/api/v1/image/assets/TEMP/9b86a9b14f0086ba2323f7422cca85c3dd149ea9?width=196"
                  alt="Carer"
                  className="w-[98px] h-[97px] object-contain"
                />
              </div>
              <span className="text-[32px] font-bold font-balsamiq text-black leading-6">
                CARER
              </span>
            </Link>

            {/* Child Card */}
            <Link
              to="/child-enter-invite-code"
              className="w-[143px] h-[164px] rounded-[30px] bg-white flex flex-col items-center justify-between p-4 hover:shadow-lg transition-shadow"
            >
              <div className="flex-1 flex items-center justify-center">
                <img
                  src="https://api.builder.io/api/v1/image/assets/TEMP/179fd7432c9732167d9e69617715943fcfd1a52e?width=124"
                  alt="Child"
                  className="w-[62px] h-[105px] object-contain"
                />
              </div>
              <span className="text-[32px] font-bold font-balsamiq text-black leading-6">
                CHILD
              </span>
            </Link>
          </div>

          {/* Subtitle */}
          <p className="text-calm-text font-bold font-balsamiq text-base text-center px-4">
            START YOUR CALM JOURNEY TOGETHER
          </p>
        </div>
      </div>
    </div>
  );
}
