import { Link } from "react-router-dom";
import { TopRightShape, BottomLeftShape } from "@/components/DecorativeShapes";
import { useState } from "react";

const themes = [
  { id: "classic", name: "CLASSIC", color: "#C6C9F2" },
  { id: "forest", name: "FOREST", color: "#9FEAD1" },
  { id: "beach", name: "BEACH", color: "#DAECFF" },
  { id: "cosy", name: "COSY", color: "#FCF0CC" },
];

export default function ChildPickTheme() {
  const [selectedTheme, setSelectedTheme] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-calm-bg relative overflow-hidden">
      <TopRightShape />
      <BottomLeftShape />
      
      <Link
        to="/child-create-avatar"
        className="absolute top-8 left-4 z-20 p-2 hover:bg-black/5 rounded-full transition-colors"
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M14 18L8 12L14 6L15.4 7.4L10.8 12L15.4 16.6L14 18Z" fill="#1D1B20" />
        </svg>
      </Link>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 py-12">
        <div className="flex flex-col items-center max-w-[375px] w-full">
          <div className="w-[318px] h-[318px] mb-6 flex items-center justify-center">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/f722ac5c1a6e81a8352dc90eaf18b6c29d5963c0?width=636"
              alt="Logo"
              className="w-full h-full object-contain"
            />
          </div>

          {/* Card */}
          <div className="bg-white rounded-[53px] p-8 w-full max-w-[330px]">
            <h1 className="text-[24px] font-bold font-balsamiq text-black text-center mb-2">
              CHOOSE YOUR APP THEME
            </h1>
            <p className="text-[12px] font-bold font-balsamiq text-black text-center mb-8">
              TIP: choose a theme that is similar to your safe space
            </p>

            {/* Theme Options */}
            <div className="space-y-4">
              {themes.map((theme) => (
                <button
                  key={theme.id}
                  onClick={() => setSelectedTheme(theme.id)}
                  className={`w-full h-20 rounded-[15px] flex items-center justify-between px-6 transition-all ${
                    selectedTheme === theme.id ? "ring-4 ring-black" : ""
                  }`}
                  style={{ backgroundColor: theme.color }}
                >
                  <svg width="50" height="50" viewBox="0 0 50 50" fill="none">
                    <path
                      d="M10.4167 43.75C9.27083 43.75 8.28125 43.3507 7.44792 42.5521C6.64931 41.7188 6.25 40.7292 6.25 39.5833V10.4167C6.25 9.27083 6.64931 8.29861 7.44792 7.5C8.28125 6.66667 9.27083 6.25 10.4167 6.25H39.5833C40.7292 6.25 41.7014 6.66667 42.5 7.5C43.3333 8.29861 43.75 9.27083 43.75 10.4167V39.5833C43.75 40.7292 43.3333 41.7188 42.5 42.5521C41.7014 43.3507 40.7292 43.75 39.5833 43.75H10.4167ZM10.4167 39.5833H39.5833V10.4167H10.4167V39.5833ZM12.5 35.4167H37.5L29.6875 25L23.4375 33.3333L18.75 27.0833L12.5 35.4167ZM10.4167 39.5833V10.4167V39.5833Z"
                      fill="#1D1B20"
                    />
                  </svg>
                  <span className="text-[40px] font-bold font-balsamiq text-black">
                    {theme.name}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
