import { Link } from "react-router-dom";
import { TopRightShape, BottomLeftShape } from "@/components/DecorativeShapes";

const tools = [
  { name: "MEDITATION", icon: "🧘" },
  { name: "BREATHING", icon: "💨" },
  { name: "YOGA", icon: "🤸" },
];

export default function CarerJointTools() {
  return (
    <div className="min-h-screen bg-calm-bg relative overflow-hidden pb-20">
      <TopRightShape />
      <BottomLeftShape />
      
      <Link
        to="/carer-home"
        className="absolute top-8 left-4 z-20 p-2 hover:bg-black/5 rounded-full transition-colors"
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M14 18L8 12L14 6L15.4 7.4L10.8 12L15.4 16.6L14 18Z" fill="#1D1B20" />
        </svg>
      </Link>

      <div className="relative z-10 px-6 py-8">
        <h1 className="text-[48px] font-bold font-balsamiq text-black text-center mb-8">
          HELPFUL TOOLS
        </h1>

        <div className="grid grid-cols-1 gap-6 max-w-[350px] mx-auto mb-8">
          {tools.map((tool) => (
            <Link key={tool.name} to="/placeholder">
              <div className="bg-white rounded-[16px] h-40 flex flex-col items-center justify-center hover:shadow-lg transition-shadow">
                <span className="text-5xl mb-2">{tool.icon}</span>
                <p className="text-lg font-bold font-balsamiq text-black text-center">
                  {tool.name}
                </p>
              </div>
            </Link>
          ))}
        </div>

        {/* Wendy Card */}
        <div className="max-w-[350px] mx-auto">
          <div className="bg-white rounded-[16px] p-6 flex flex-col items-center">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/5719963dd2f54035eab26d9232d11bb460d3a884?width=238"
              alt="Wendy"
              className="w-32 h-40 object-contain mb-4"
            />
            <p className="text-lg font-bold font-balsamiq text-black text-center">
              SPEAK TO WENDY
            </p>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center h-16">
        <NavItem icon="home" label="Home" to="/carer-home" />
        <NavItem icon="journal" label="Journal" />
        <NavItem icon="settings" label="Settings" />
        <NavItem icon="help" label="Help" />
      </nav>
    </div>
  );
}

function NavItem({ icon, label, to = "/" }: { icon: string; label: string; to?: string }) {
  return (
    <Link to={to} className="flex flex-col items-center gap-1 py-2 px-4">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        {icon === "home" && (
          <path
            d="M9.875 22V12H15.875V22M3.875 9L12.875 2L21.875 9V20C21.875 20.5304 21.6643 21.0391 21.2892 21.4142C20.9141 21.7893 20.4054 22 19.875 22H5.875C5.34457 22 4.83586 21.7893 4.46079 21.4142C4.08571 21.0391 3.875 20.5304 3.875 20V9Z"
            stroke="#49454F"
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        )}
        {icon === "journal" && (
          <path
            d="M4.625 19.5C4.625 18.837 4.88839 18.2011 5.35723 17.7322C5.82607 17.2634 6.46196 17 7.125 17H20.625M4.625 19.5C4.625 20.163 4.88839 20.7989 5.35723 21.2678C5.82607 21.7366 6.46196 22 7.125 22H20.625V2H7.125C6.46196 2 5.82607 2.26339 5.35723 2.73223C4.88839 3.20107 4.625 3.83696 4.625 4.5V19.5Z"
            stroke="#49454F"
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        )}
        {icon === "settings" && (
          <path
            d="M9.62501 22L9.22501 18.8C9.00835 18.7167 8.80418 18.6167 8.61251 18.5C8.42085 18.3833 8.23335 18.2583 8.05001 18.125L5.07501 19.375L2.32501 14.625L4.90001 12.675C4.88335 12.5583 4.87501 12.4458 4.87501 12.3375V11.6625C4.87501 11.5542 4.88335 11.4417 4.90001 11.325L2.32501 9.375L5.07501 4.625L8.05001 5.875C8.23335 5.74167 8.42501 5.61667 8.62501 5.5C8.82501 5.38333 9.02501 5.28333 9.22501 5.2L9.62501 2H15.125L15.525 5.2C15.7417 5.28333 15.9458 5.38333 16.1375 5.5C16.3292 5.61667 16.5167 5.74167 16.7 5.875L19.675 4.625L22.425 9.375L19.85 11.325C19.8667 11.4417 19.875 11.5542 19.875 11.6625V12.3375C19.875 12.4458 19.8583 12.5583 19.825 12.675L22.4 14.625L19.65 19.375L16.7 18.125C16.5167 18.2583 16.325 18.3833 16.125 18.5C15.925 18.6167 15.725 18.7167 15.525 18.8L15.125 22H9.62501ZM11.375 20H13.35L13.7 17.35C14.2167 17.2167 14.6958 17.0208 15.1375 16.7625C15.5792 16.5042 15.9833 16.1917 16.35 15.825L18.825 16.85L19.8 15.15L17.65 13.525C17.7333 13.2917 17.7917 13.0458 17.825 12.7875C17.8583 12.5292 17.875 12.2667 17.875 12C17.875 11.7333 17.8583 11.4708 17.825 11.2125C17.7917 10.9542 17.7333 10.7083 17.65 10.475L19.8 8.85L18.825 7.15L16.35 8.2C15.9833 7.81667 15.5792 7.49583 15.1375 7.2375C14.6958 6.97917 14.2167 6.78333 13.7 6.65L13.375 4H11.4L11.05 6.65C10.5333 6.78333 10.0542 6.97917 9.61251 7.2375C9.17085 7.49583 8.76668 7.80833 8.40001 8.175L5.92501 7.15L4.95001 8.85L7.10001 10.45C7.01668 10.7 6.95835 10.95 6.92501 11.2C6.89168 11.45 6.87501 11.7167 6.87501 12C6.87501 12.2667 6.89168 12.525 6.92501 12.775C6.95835 13.025 7.01668 13.275 7.10001 13.525L4.95001 15.15L5.92501 16.85L8.40001 15.8C8.76668 16.1833 9.17085 16.5042 9.61251 16.7625C10.0542 17.0208 10.5333 17.2167 11.05 17.35L11.375 20ZM12.425 15.5C13.3917 15.5 14.2167 15.1583 14.9 14.475C15.5833 13.7917 15.925 12.9667 15.925 12C15.925 11.0333 15.5833 10.2083 14.9 9.525C14.2167 8.84167 13.3917 8.5 12.425 8.5C11.4417 8.5 10.6125 8.84167 9.93751 9.525C9.26251 10.2083 8.92501 11.0333 8.92501 12C8.92501 12.9667 9.26251 13.7917 9.93751 14.475C10.6125 15.1583 11.4417 15.5 12.425 15.5Z"
            fill="#49454F"
          />
        )}
        {icon === "help" && (
          <path
            d="M9.215 9C9.4501 8.33167 9.91415 7.76811 10.525 7.40913C11.1358 7.05016 11.8539 6.91894 12.5522 7.03871C13.2505 7.15849 13.8838 7.52152 14.3401 8.06353C14.7963 8.60553 15.0461 9.29152 15.045 10C15.045 12 12.045 13 12.045 13M12.125 17H12.135M22.125 12C22.125 17.5228 17.6478 22 12.125 22C6.60215 22 2.125 17.5228 2.125 12C2.125 6.47715 6.60215 2 12.125 2C17.6478 2 22.125 6.47715 22.125 12Z"
            stroke="#454343"
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        )}
      </svg>
      <span className="text-xs font-semibold text-gray-600">{label}</span>
    </Link>
  );
}
