import { Link } from "react-router-dom";
import { TopRightShape, BottomLeftShape } from "@/components/DecorativeShapes";
import { GradientButton } from "@/components/GradientButton";
import { useState } from "react";

export default function CarerInviteCode() {
  const [code] = useState("ABC123XYZ");

  return (
    <div className="min-h-screen bg-calm-bg relative overflow-hidden">
      <TopRightShape />
      <BottomLeftShape />
      
      <Link
        to="/carer-privacy"
        className="absolute top-8 left-4 z-20 p-2 hover:bg-black/5 rounded-full transition-colors"
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M14 18L8 12L14 6L15.4 7.4L10.8 12L15.4 16.6L14 18Z" fill="#1D1B20" />
        </svg>
      </Link>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 py-12">
        <div className="flex flex-col items-center max-w-[375px] w-full">
          <div className="w-[113px] h-[113px] mb-6 flex items-center justify-center">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/52e024e4615122cbeb548c13ef1bbaa053452ca4?width=226"
              alt="Logo"
              className="w-full h-full object-contain"
            />
          </div>

          {/* Card */}
          <div className="bg-white rounded-[53px] p-8 w-full max-w-[330px] mb-6">
            <h1 className="text-[36px] font-bold font-balsamiq text-black text-center mb-4">
              INVITE MY CHILD
            </h1>
            <p className="text-[24px] font-balsamiq text-black text-center mb-6">
              Generate a code
            </p>

            {/* Code Display */}
            <div className="border border-black rounded-[10px] py-4 px-6 text-center font-balsamiq text-xl font-bold text-black mb-6">
              {code}
            </div>

            {/* Send Code Button */}
            <div className="flex justify-center mb-6">
              <GradientButton variant="secondary">
                Send code
              </GradientButton>
            </div>

            {/* Explore Button */}
            <div className="bg-calm-peachLight rounded-full py-3 px-4 text-center font-balsamiq text-base text-black">
              Explore tools while you wait :)
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
