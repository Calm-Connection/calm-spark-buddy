import { Link } from "react-router-dom";
import { TopRightShape, BottomLeftShape } from "@/components/DecorativeShapes";
import { GradientButton } from "@/components/GradientButton";
import { useState } from "react";

export default function JournalEntry() {
  const [feeling, setFeeling] = useState<number | null>(null);
  const [entryType, setEntryType] = useState<"write" | "draw" | "speak" | null>(null);

  const feelings = [1, 2, 3, 4, 5];

  return (
    <div className="min-h-screen bg-calm-bg relative overflow-hidden pb-20">
      <TopRightShape />
      <BottomLeftShape />

      <div className="relative z-10 px-6 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <Link to="/" className="p-2 hover:bg-black/5 rounded-full transition-colors">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M14 18L8 12L14 6L15.4 7.4L10.8 12L15.4 16.6L14 18Z" fill="#1D1B20" />
            </svg>
          </Link>
          <svg width="37" height="37" viewBox="0 0 37 37" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M6.16663 30.0627C6.16663 29.0405 6.57269 28.0602 7.29549 27.3374C8.01828 26.6146 8.9986 26.2085 10.0208 26.2085H30.8333M6.16663 30.0627C6.16663 31.0849 6.57269 32.0652 7.29549 32.788C8.01828 33.5108 8.9986 33.9168 10.0208 33.9168H30.8333V3.0835H10.0208C8.9986 3.0835 8.01828 3.48956 7.29549 4.21236C6.57269 4.93515 6.16663 5.91547 6.16663 6.93766V30.0627Z"
              stroke="#454343"
              strokeWidth="4"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>

        {/* Avatar */}
        <div className="flex justify-center mb-6">
          <svg
            width="209"
            height="209"
            viewBox="0 0 209 209"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-32 h-32"
          >
            <rect width="209" height="209" rx="100" fill="#EADDFF" />
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M135.851 83.6C135.851 100.914 121.815 114.95 104.501 114.95C87.1871 114.95 73.1513 100.914 73.1513 83.6C73.1513 66.2859 87.1871 52.25 104.501 52.25C121.815 52.25 135.851 66.2859 135.851 83.6ZM125.401 83.6C125.401 95.1427 116.044 104.5 104.501 104.5C92.9585 104.5 83.6013 95.1427 83.6013 83.6C83.6013 72.0572 92.9585 62.7 104.501 62.7C116.044 62.7 125.401 72.0572 125.401 83.6Z"
              fill="#4F378A"
            />
            <path
              d="M104.501 130.625C70.6726 130.625 41.8497 150.628 30.8704 178.653C33.545 181.309 36.3626 183.822 39.3105 186.177C47.4862 160.448 73.1341 141.075 104.501 141.075C135.868 141.075 161.516 160.448 169.692 186.178C172.64 183.822 175.458 181.309 178.132 178.654C167.153 150.628 138.33 130.625 104.501 130.625Z"
              fill="#4F378A"
            />
          </svg>
        </div>

        {/* Title */}
        <h1 className="text-[48px] font-bold font-balsamiq text-black text-center mb-4">
          HI, ALEX
        </h1>
        <p className="text-[20px] font-balsamiq text-black text-center mb-6">
          HOW ARE YOU FEELING TODAY?
        </p>

        {/* Feeling Selection */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          {feelings.map((f) => (
            <button
              key={f}
              onClick={() => setFeeling(f)}
              className={`w-16 h-16 rounded-full flex items-center justify-center transition-all ${
                feeling === f ? "ring-4 ring-black scale-110" : "hover:scale-105"
              }`}
              style={{ backgroundColor: "#C6C9F2" }}
            >
              <svg width="35" height="35" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M17 3.17383L21.2721 11.8288L30.8257 13.2252L23.9128 19.9583L25.5443 29.4704L17 24.977L8.45563 29.4704L10.0871 19.9583L3.17419 13.2252L12.7278 11.8288L17 3.17383Z"
                  stroke="#F5F5F5"
                  strokeWidth="3.31818"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>
          ))}
        </div>

        {/* Entry Type Selection */}
        {feeling && (
          <div className="space-y-4 mb-8">
            <p className="text-[20px] font-bold font-balsamiq text-black text-center mb-6">
              WHAT MADE YOU FEEL {feeling === 1 ? "SAD" : feeling === 2 ? "ANXIOUS" : "HAPPY"}?
            </p>

            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => setEntryType("write")}
                className={`h-14 rounded-[7px] flex items-center justify-center font-bold font-balsamiq text-2xl transition-all ${
                  entryType === "write"
                    ? "bg-calm-cream ring-2 ring-black"
                    : "bg-calm-cream hover:shadow-lg"
                }`}
              >
                WRITE
              </button>
              <button
                onClick={() => setEntryType("draw")}
                className={`h-14 rounded-[7px] flex items-center justify-center font-bold font-balsamiq text-2xl transition-all ${
                  entryType === "draw"
                    ? "bg-calm-cream ring-2 ring-black"
                    : "bg-calm-cream hover:shadow-lg"
                }`}
              >
                DRAW
              </button>
            </div>

            <button
              onClick={() => setEntryType("speak")}
              className={`w-full h-14 rounded-[7px] flex items-center justify-center font-bold font-balsamiq text-2xl transition-all ${
                entryType === "speak"
                  ? "bg-calm-cream ring-2 ring-black"
                  : "bg-calm-cream hover:shadow-lg"
              }`}
            >
              SPEAK
            </button>
          </div>
        )}

        {entryType && (
          <div className="space-y-4 mb-8">
            <div className="bg-white rounded-[20px] h-72 p-4 border-2 border-black">
              {/* Entry area would go here */}
            </div>

            <div className="flex gap-4">
              <button className="flex-1 bg-calm-peachLight rounded-full py-3 font-balsamiq font-semibold text-black hover:shadow-lg transition-shadow">
                SEND TO CARER
              </button>
              <button className="flex-1 bg-calm-peachLight rounded-full py-3 font-balsamiq font-semibold text-black hover:shadow-lg transition-shadow">
                SAVE
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
