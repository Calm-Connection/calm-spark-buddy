import { Link } from "react-router-dom";
import { TopRightShape, BottomLeftShape } from "@/components/DecorativeShapes";
import { GradientButton } from "@/components/GradientButton";
import { useState } from "react";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle login logic here
  };

  return (
    <div className="min-h-screen bg-calm-bg relative overflow-hidden">
      <TopRightShape />
      <BottomLeftShape />
      
      {/* Back button */}
      <Link
        to="/"
        className="absolute top-8 left-4 z-20 p-2 hover:bg-black/5 rounded-full transition-colors"
      >
        <svg
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M14 18L8 12L14 6L15.4 7.4L10.8 12L15.4 16.6L14 18Z"
            fill="#1D1B20"
          />
        </svg>
      </Link>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 py-12">
        <div className="flex flex-col items-center max-w-[375px] w-full">
          {/* Logo */}
          <div className="w-[318px] h-[318px] mb-6 flex items-center justify-center">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/f722ac5c1a6e81a8352dc90eaf18b6c29d5963c0?width=636"
              alt="Calm Connection Logo"
              className="w-full h-full object-contain"
            />
          </div>

          {/* Welcome Text */}
          <h1 className="text-[40px] font-bold font-balsamiq text-black text-center leading-6 mb-8">
            WELCOME
          </h1>

          {/* Form */}
          <form onSubmit={handleSubmit} className="w-full flex flex-col items-center gap-8">
            {/* Username Input */}
            <div className="relative w-full max-w-[300px]">
              <div className="absolute left-4 top-1/2 -translate-y-1/2">
                <svg
                  width="46"
                  height="46"
                  viewBox="0 0 46 46"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M11.2125 32.775C12.8416 31.5292 14.6625 30.5469 16.675 29.8281C18.6875 29.1094 20.7958 28.75 23 28.75C25.2041 28.75 27.3125 29.1094 29.325 29.8281C31.3375 30.5469 33.1583 31.5292 34.7875 32.775C35.9055 31.4653 36.776 29.9799 37.3989 28.3188C38.0219 26.6577 38.3333 24.8847 38.3333 23C38.3333 18.7514 36.8399 15.1337 33.8531 12.1469C30.8663 9.16008 27.2486 7.66668 23 7.66668C18.7514 7.66668 15.1337 9.16008 12.1469 12.1469C9.16005 15.1337 7.66665 18.7514 7.66665 23C7.66665 24.8847 7.9781 26.6577 8.60102 28.3188C9.22394 29.9799 10.0944 31.4653 11.2125 32.775ZM23 24.9167C21.1153 24.9167 19.526 24.2698 18.2323 22.9761C16.9385 21.6823 16.2916 20.0931 16.2916 18.2083C16.2916 16.3236 16.9385 14.7344 18.2323 13.4406C19.526 12.1469 21.1153 11.5 23 11.5C24.8847 11.5 26.4739 12.1469 27.7677 13.4406C29.0614 14.7344 29.7083 16.3236 29.7083 18.2083C29.7083 20.0931 29.0614 21.6823 27.7677 22.9761C26.4739 24.2698 24.8847 24.9167 23 24.9167ZM23 42.1667C20.3486 42.1667 17.8569 41.6636 15.525 40.6573C13.193 39.6511 11.1646 38.2854 9.43956 36.5604C7.71456 34.8354 6.34894 32.807 5.34269 30.475C4.33644 28.1431 3.83331 25.6514 3.83331 23C3.83331 20.3486 4.33644 17.857 5.34269 15.525C6.34894 13.1931 7.71456 11.1646 9.43956 9.43959C11.1646 7.71459 13.193 6.34897 15.525 5.34272C17.8569 4.33647 20.3486 3.83334 23 3.83334C25.6514 3.83334 28.143 4.33647 30.475 5.34272C32.8069 6.34897 34.8354 7.71459 36.5604 9.43959C38.2854 11.1646 39.651 13.1931 40.6573 15.525C41.6635 17.857 42.1666 20.3486 42.1666 23C42.1666 25.6514 41.6635 28.1431 40.6573 30.475C39.651 32.807 38.2854 34.8354 36.5604 36.5604C34.8354 38.2854 32.8069 39.6511 30.475 40.6573C28.143 41.6636 25.6514 42.1667 23 42.1667Z"
                    fill="#FCF0CC"
                  />
                </svg>
              </div>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="USERNAME"
                className="w-full h-8 pl-16 pr-4 rounded-[19px] border border-black bg-white font-balsamiq text-base leading-6 placeholder:text-black focus:outline-none focus:ring-2 focus:ring-calm-purple"
              />
            </div>

            {/* Password Input */}
            <div className="relative w-full max-w-[300px]">
              <div className="absolute left-4 top-1/2 -translate-y-1/2">
                <svg
                  width="39"
                  height="39"
                  viewBox="0 0 39 39"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M11.375 17.875V11.375C11.375 9.22012 12.231 7.15349 13.7548 5.62976C15.2785 4.10602 17.3451 3.25 19.5 3.25C21.6549 3.25 23.7215 4.10602 25.2452 5.62976C26.769 7.15349 27.625 9.22012 27.625 11.375V17.875M8.125 17.875H30.875C32.6699 17.875 34.125 19.3301 34.125 21.125V32.5C34.125 34.2949 32.6699 35.75 30.875 35.75H8.125C6.33007 35.75 4.875 34.2949 4.875 32.5V21.125C4.875 19.3301 6.33007 17.875 8.125 17.875Z"
                    stroke="#FCF0CC"
                    strokeWidth="4"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="PASSWORD"
                className="w-full h-8 pl-16 pr-4 rounded-[19px] border border-black bg-white font-balsamiq text-base leading-6 placeholder:text-black focus:outline-none focus:ring-2 focus:ring-calm-purple"
              />
            </div>

            {/* Login Button */}
            <GradientButton variant="secondary" type="submit" className="mt-2">
              LOG IN
            </GradientButton>
          </form>

          {/* Forgot Password Link */}
          <button className="mt-8 text-black font-balsamiq text-xl hover:underline">
            Forgot Password
          </button>

          {/* Don't Have Account Link */}
          <Link
            to="/role-selection"
            className="absolute bottom-8 right-6 text-black font-balsamiq text-base hover:underline"
          >
            Don't Have an Account?
          </Link>
        </div>
      </div>
    </div>
  );
}
