import { Link } from "react-router-dom";
import { TopRightShape, BottomLeftShape } from "@/components/DecorativeShapes";
import { GradientButton } from "@/components/GradientButton";
import { useState } from "react";

const avatarOptions = [
  { id: 1, x: 46, y: 177 },
  { id: 2, x: 204, y: 178 },
  { id: 3, x: 46, y: 333 },
  { id: 4, x: 204, y: 334 },
  { id: 5, x: 46, y: 489 },
  { id: 6, x: 204, y: 490 },
];

const AvatarPlaceholder = ({ selected }: { selected: boolean }) => (
  <svg
    width="124"
    height="124"
    viewBox="0 0 124 124"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`w-full h-full ${selected ? "ring-4 ring-calm-mint" : ""}`}
  >
    <rect width="124" height="124" rx="62" fill="#EADDFF" />
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M80.6008 49.6C80.6008 59.8725 72.2733 68.2 62.0008 68.2C51.7283 68.2 43.4008 59.8725 43.4008 49.6C43.4008 39.3275 51.7283 31 62.0008 31C72.2733 31 80.6008 39.3275 80.6008 49.6ZM74.4008 49.6C74.4008 56.4483 68.8491 62 62.0008 62C55.1524 62 49.6008 56.4483 49.6008 49.6C49.6008 42.7517 55.1524 37.2 62.0008 37.2C68.8491 37.2 74.4008 42.7517 74.4008 49.6Z"
      fill="#4F378A"
    />
    <path
      d="M62.0008 77.5C41.9302 77.5 24.8295 89.3681 18.3154 105.995C19.9023 107.571 21.574 109.062 23.3229 110.459C28.1736 95.1939 43.3906 83.7 62.0008 83.7C80.611 83.7 95.8279 95.1939 100.679 110.459C102.428 109.062 104.099 107.571 105.686 105.995C99.1721 89.3681 82.0714 77.5 62.0008 77.5Z"
      fill="#4F378A"
    />
  </svg>
);

export default function CarerPickAvatar() {
  const [selectedAvatar, setSelectedAvatar] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-calm-bg relative overflow-hidden">
      <TopRightShape />
      <BottomLeftShape />
      
      <Link
        to="/carer-invite-code"
        className="absolute top-8 left-4 z-20 p-2 hover:bg-black/5 rounded-full transition-colors"
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M14 18L8 12L14 6L15.4 7.4L10.8 12L15.4 16.6L14 18Z" fill="#1D1B20" />
        </svg>
      </Link>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 py-8">
        <div className="flex flex-col items-center max-w-[375px] w-full">
          <h1 className="text-[32px] font-bold font-balsamiq text-black text-center mb-8">
            PICK YOUR AVATAR
          </h1>

          {/* Avatar Grid */}
          <div className="bg-white rounded-[20px] p-8 w-full max-w-[345px] mb-6">
            <div className="grid grid-cols-2 gap-6">
              {avatarOptions.map((avatar) => (
                <button
                  key={avatar.id}
                  onClick={() => setSelectedAvatar(avatar.id)}
                  className="h-[124px] hover:scale-105 transition-transform"
                >
                  <AvatarPlaceholder selected={selectedAvatar === avatar.id} />
                </button>
              ))}
            </div>
          </div>

          {/* Next Button */}
          <Link
            to={selectedAvatar ? "/carer-home" : "#"}
            onClick={(e) => !selectedAvatar && e.preventDefault()}
            className={`${!selectedAvatar ? "opacity-50 cursor-not-allowed" : ""}`}
          >
            <GradientButton variant="secondary">
              NEXT
            </GradientButton>
          </Link>
        </div>
      </div>
    </div>
  );
}
