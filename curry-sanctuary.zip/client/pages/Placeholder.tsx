import { Link } from "react-router-dom";
import { TopRightShape, BottomLeftShape } from "@/components/DecorativeShapes";

export default function Placeholder() {
  return (
    <div className="min-h-screen bg-calm-bg relative overflow-hidden">
      <TopRightShape />
      <BottomLeftShape />
      
      {/* Back button */}
      <Link
        to="/"
        className="absolute top-8 left-4 z-20 p-2 hover:bg-black/5 rounded-full transition-colors"
      >
        <svg
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M14 18L8 12L14 6L15.4 7.4L10.8 12L15.4 16.6L14 18Z"
            fill="#1D1B20"
          />
        </svg>
      </Link>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 py-12">
        <div className="flex flex-col items-center max-w-[500px] w-full bg-white/90 backdrop-blur-sm rounded-[53px] p-8 shadow-lg">
          {/* Logo */}
          <div className="w-32 h-32 mb-6">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/f722ac5c1a6e81a8352dc90eaf18b6c29d5963c0?width=636"
              alt="Calm Connection Logo"
              className="w-full h-full object-contain"
            />
          </div>

          <h1 className="text-3xl font-bold font-balsamiq text-black text-center mb-4">
            Coming Soon
          </h1>
          
          <p className="text-lg font-balsamiq text-black text-center mb-6">
            This page is being built with care. Continue exploring to see more of Calm Connection!
          </p>

          <Link
            to="/"
            className="px-8 py-3 bg-calm-purple hover:bg-calm-peach transition-colors rounded-full font-balsamiq text-xl text-black"
          >
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
