import { Link, useSearchParams } from "react-router-dom";
import { TopRightShape, BottomLeftShape } from "@/components/DecorativeShapes";
import { GradientButton } from "@/components/GradientButton";
import { useState } from "react";

const tourScreens = [
  {
    id: 0,
    title: "🩵 Quick Tour",
    subtitle: "Calming Tools",
    description: "Explore calming tools and guided exercises to help when things feel too much.\n\nBreathe. Pause. Reset.",
  },
  {
    id: 1,
    title: "🩵 Quick Tour",
    subtitle: "✨ Meet Wendy (Your AI Guide)",
    description: "Wendy helps you understand your emotions and find tools that fit how you feel.\n\nShe listens — but she's not a therapist. Just a caring guide.",
    showImage: true,
  },
  {
    id: 2,
    title: "🩵 Quick Tour",
    subtitle: "Safety First",
    description: "Your safety matters most.\nIf something you share sounds worrying, we'll help you get the right support.",
  },
  {
    id: 3,
    title: "🩵 Quick Tour",
    subtitle: "You're ready to start your Calm Connection journey. 🩵",
    description: "",
    showButton: true,
  },
];

export default function ChildQuickTour() {
  const [searchParams] = useSearchParams();
  const screenId = parseInt(searchParams.get("screen") || "0");
  const screen = tourScreens[screenId];

  const nextScreen = screenId < tourScreens.length - 1 ? screenId + 1 : null;

  return (
    <div className="min-h-screen bg-calm-bg relative overflow-hidden">
      <TopRightShape />
      <BottomLeftShape />
      
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 py-12">
        <div className="flex flex-col items-center max-w-[375px] w-full">
          {/* Card */}
          <div className="bg-white rounded-[53px] p-8 w-full max-w-[330px] min-h-[700px] flex flex-col">
            <h1 className="text-[32px] font-balsamiq text-black text-center mb-6 leading-10">
              {screen.title}
            </h1>

            {screen.showImage && (
              <div className="flex justify-center mb-6">
                <img
                  src="https://api.builder.io/api/v1/image/assets/TEMP/3b18503211e0bc5a778c82ce72e404b440998307?width=276"
                  alt="Wendy"
                  className="w-32 h-44 object-contain"
                />
              </div>
            )}

            <div className="flex-1 flex flex-col justify-center">
              <p className="text-[20px] font-bold font-balsamiq text-black text-center mb-4">
                {screen.subtitle}
              </p>
              {screen.description && (
                <p className="text-[20px] font-balsamiq text-black text-center whitespace-pre-line">
                  {screen.description}
                </p>
              )}
            </div>

            {screen.showButton && (
              <div className="mt-6 flex justify-center">
                <Link to="/child-home">
                  <GradientButton variant="secondary">
                    Let's Begin →
                  </GradientButton>
                </Link>
              </div>
            )}
          </div>

          {/* Navigation */}
          {nextScreen !== null && (
            <div className="flex justify-end mt-8 w-full max-w-[330px]">
              <Link to={`/child-quick-tour?screen=${nextScreen}`}>
                <svg width="52" height="57" viewBox="0 0 52 57" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M27.3 28.5L17.3333 17.575L20.3667 14.25L33.3667 28.5L20.3667 42.75L17.3333 39.425L27.3 28.5Z"
                    fill="#1D1B20"
                  />
                </svg>
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
