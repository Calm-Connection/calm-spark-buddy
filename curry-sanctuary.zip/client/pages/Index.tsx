import { Link } from "react-router-dom";
import { TopRightShape, BottomLeftShape } from "@/components/DecorativeShapes";
import { GradientButton } from "@/components/GradientButton";

export default function Index() {
  return (
    <div className="min-h-screen bg-calm-bg relative overflow-hidden">
      <TopRightShape />
      <BottomLeftShape />
      
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 py-12">
        <div className="flex flex-col items-center max-w-[375px] w-full">
          {/* Logo */}
          <div className="w-[318px] h-[318px] mb-8 flex items-center justify-center">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/f722ac5c1a6e81a8352dc90eaf18b6c29d5963c0?width=636"
              alt="Calm Connection Logo"
              className="w-full h-full object-contain"
            />
          </div>

          {/* Welcome Text */}
          <h1 className="text-[64px] font-bold font-balsamiq text-black text-center leading-[41px] mb-12">
            WELCOME
          </h1>

          {/* Get Started Button */}
          <Link to="/login">
            <GradientButton variant="primary">
              GET STARTED
            </GradientButton>
          </Link>
        </div>
      </div>
    </div>
  );
}
